#!/bin/bash

# Import terminal colors
RED="\e[31m"
GREEN="\e[32m"
BLUE="\e[34m"
LIGHT_GRAY="\e[37m"
YELLOW="\e[33m"
PURPLE="\e[35m"
BOLD="\033[1m"
DEFAULT="\e[0m"

# Check the program arguments
if [ $1 = "-y" ] || [ $1 = "-Y" ]
then
    ask_user=false
    generated_tests="Y"
else
    ask_user=true
fi

# Locate all the needed files
parse_path=$(pwd)/parse.py
jexamxml_path=$(pwd)/jexamxml/jexamxml.jar
jexamxml_options_path=$(pwd)/jexamxml/options

if ! [ -f $parse_path ] # parse.py
then
    clear
    echo -e "${RED}ERROR: Could not locate the 'parse.py' file...\n\n${GREEN}Are you sure it's in the same directory as this script??"
    exit 1
fi

if ! [ -f $jexamxml_path ] # jexamxml.jar
then
    clear
    echo -e "${RED}ERROR: Could not locate the 'jexamxml.jar' file...\n\n${GREEN}Check README.md for usage info..."
    exit 1
fi

if ! [ -f $jexamxml_options_path ] # options
then
    clear
    echo -e "${RED}ERROR: Could not locate the 'options' file...\n\n${GREEN}Check README.md for usage info..."
    exit 1
fi

# Check if java is installed
echo "java --version"

if [ $? -ne 0 ]
then
    echo -e "${RED}ERROR: It seems like you don't have Java installed...\n\n${GREEN}Should I run the return code tests at least?? [Y/n]"
    read -s flag_bool
    if [ "$flag_bool" = "Y" ] || [ "$flag_bool" = "y" ]  
    then
        rc_tests_only="Y"
    else
        exit 0
    fi
else
    rc_tests_only="N"
fi

# Create variables to keep track of all the different test statistics
test_cnt=0
test_cnt_tmp=0
tests_passed=0
tests_passed_tmp=0

# Function to test the return code
test_script_args(){
    args_cnt=$1         # Arguments count
    exp_ret_code=$2     # Expected return code
    test_description=$3 # The test description
    test_cnt=$4         # Test count
    arguments=$5        # Arguments
    test_file=$(pwd)$6  # Program input file 
    test_cnt_tmp=$7     # Program input file 

    printf "${LIGHT_GRAY}[Test $test_cnt] – $test_description\n" # Print information about the current test

    python3 $parse_path $arguments < $test_file > /dev/null 2>&1 # Run the parse.py script

    ret_code=$? # Save the return code

    # Check if the return code is matching
    if [ $exp_ret_code -eq $ret_code ]
    then
        printf "${BLUE}Expected $exp_ret_code, recieved $ret_code.\n"
        echo -e "${GREEN}Test passed ✓ ${DEFAULT}\n"
        # Increase the passed tests count
        tests_passed=$(($tests_passed + 1))
        tests_passed_tmp=$(($tests_passed_tmp + 1))
    else
        printf "${BLUE}Expected $exp_ret_code, recieved $ret_code.\n"
        echo -e "${RED}Test failed ⨯ ${DEFAULT}\n"
    fi

    # Increase the test counts
    test_cnt=$(($test_cnt + 1))
    test_cnt_tmp=$(($test_cnt_tmp + 1))
}

# Function to test the XML generated code
test_script_output(){
    exp_ret_code=$1      # Expected return code
    test_description=$2  # The test description
    test_cnt=$3          # Test count
    test_file=$(pwd)$4   # Program input file 
    ref_output=$(pwd)$5  # Correct output
    test_cnt_tmp=$6      # Program input file 

    printf "${LIGHT_GRAY}[Test $test_cnt] – $test_description\n" # Print information about the current test

    python3 $parse_path < $test_file > "tmp_file.out" # Run the parse.py script

    ret_code=$? # Save the return code
    
    # Run the Jexamxml to compare the outputs
    java -jar $jexamxml_path $ref_output tmp_file.out "diffs.xml"  $jexamxml_options_path > /dev/null 2>&1

    jexamxml_ret_code=$? # Save the return code

    # Check if the return code is matching
    if [ $jexamxml_ret_code -eq 0 ] && [ $exp_ret_code -eq $ret_code ]
    then
        printf "${BLUE}Expected $exp_ret_code, recieved $ret_code.\n"
        echo -e "${GREEN}Test passed ✓ ${DEFAULT}\n"
        # Increase the passed tests count
        tests_passed=$(($tests_passed + 1))
        tests_passed_tmp=$(($tests_passed_tmp + 1))
    else # The return code is not matching
        printf "${BLUE}Expected $exp_ret_code, recieved $ret_code.\n"
        echo -e "${RED}Test failed ⨯ ${DEFAULT}\n"
    fi

    # Increase the test count
    test_cnt=$(($test_cnt + 1))
    test_cnt_tmp=$(($test_cnt_tmp + 1))
}

clear

# Call the tests

# TESTS 0 - 5 (arguments)
test_script_args 0 0 "No arguments" $test_cnt "" "/tests/arguments/test_file" $test_cnt_tmp
test_script_args 1 10 "Invalid argument" $test_cnt "--hello" "/tests/arguments/test_file" $test_cnt_tmp
test_script_args 1 0 "Valid [--help] argument" $test_cnt "--help" "/tests/arguments/test_file" $test_cnt_tmp
test_script_args 2 10 "Valid and invalid argument" $test_cnt "--help hello" "/tests/arguments/test_file" $test_cnt_tmp
test_script_args 2 10 "More than 1 argument" $test_cnt "hello1 --help" "/tests/arguments/test_file" $test_cnt_tmp
test_script_args 3 10 "More than 2 arguments" $test_cnt "hello1 hello2 --help" "/tests/arguments/test_file" $test_cnt_tmp

# Save information about the argument tests
program_args_tests="${BOLD}${LIGHT_GRAY}Program arguments:${DEFAULT}\n\t${GREEN}TESTS PASSED = $tests_passed_tmp/$test_cnt_tmp\n\t${RED}TESTS FAILED = $(($test_cnt_tmp - $tests_passed_tmp))/$test_cnt_tmp\n\n${DEFAULT}"
tests_passed_tmp=0
test_cnt_tmp=0

# TESTS 6 - 20 (header)
test_script_args 0 21 "Header missing" $test_cnt "" "/tests/header/header_missing" $test_cnt_tmp
test_script_args 0 21 "Empty program with no header" $test_cnt "" "/tests/header/emptyy_test" $test_cnt_tmp
test_script_args 0 0  "Only a header" $test_cnt "" "/tests/header/header_only" $test_cnt_tmp
test_script_args 0 21 "Header at the end of the file" $test_cnt "" "/tests/header/header_end" $test_cnt_tmp
test_script_args 0 21 "Header in the middle of the file" $test_cnt "" "/tests/header/header_middle" $test_cnt_tmp
test_script_args 0 21 "Incorrect header" $test_cnt "" "/tests/header/header_incorrect" $test_cnt_tmp
test_script_args 0 23 "More than one header" $test_cnt "" "/tests/header/header_too_many" $test_cnt_tmp
test_script_args 0 0 "Some white space before the header" $test_cnt "" "/tests/header/header_white-spaces" $test_cnt_tmp
test_script_args 0 0 "Comments before the header" $test_cnt "" "/tests/header/header_comments_before" $test_cnt_tmp
test_script_args 0 0 "Some white space and comments before the header" $test_cnt "" "/tests/header/header_comments_white-spaces" $test_cnt_tmp
test_script_args 0 0 "A comment right after the header" $test_cnt "" "/tests/header/header_with_comment" $test_cnt_tmp
test_script_args 0 21 "Header with . missing" $test_cnt "" "/tests/header/no_dott" $test_cnt_tmp
test_script_args 0 0 "Lettercased header" $test_cnt "" "/tests/header/header_wrong_format" $test_cnt_tmp
test_script_args 0 0 "Header with comments everywhere" $test_cnt "" "/tests/header/comments" $test_cnt_tmp
test_script_args 0 21 "White space in the middle of the header" $test_cnt "" "/tests/header/header_space_between" $test_cnt_tmp

# Save information about the header tests
file_header_tests="${BOLD}${LIGHT_GRAY}File header:${DEFAULT}\n\t${GREEN}TESTS PASSED = $tests_passed_tmp/$test_cnt_tmp\n\t${RED}TESTS FAILED = $(($test_cnt_tmp - $tests_passed_tmp))/$test_cnt_tmp\n\n${DEFAULT}"
tests_passed_tmp=0
test_cnt_tmp=0

# TESTS 21 - 28 (opcode)
test_script_args 0 0 "Lowercased opcode ~ version 1" $test_cnt "" "/tests/opcode/lowercased_1" $test_cnt_tmp
test_script_args 0 0 "Lowercased opcode ~ version 2" $test_cnt "" "/tests/opcode/lowercased_2" $test_cnt_tmp
test_script_args 0 0 "Mix of lowercased and uppercased opcode ~ version 1" $test_cnt "" "/tests/opcode/mixed_1" $test_cnt_tmp
test_script_args 0 0 "Mix of lowercased and uppercased opcode ~ version 2" $test_cnt "" "/tests/opcode/mixed_2" $test_cnt_tmp
test_script_args 0 22 "Invalid opcode ~ version 1" $test_cnt "" "/tests/opcode/invalid_1" $test_cnt_tmp
test_script_args 0 22 "Invalid opcode ~ version 2" $test_cnt "" "/tests/opcode/invalid_2" $test_cnt_tmp
test_script_args 0 22 "Invalid opcode ~ version 3" $test_cnt "" "/tests/opcode/invalid_3" $test_cnt_tmp
test_script_args 0 22 "No space between opcode and operand" $test_cnt "" "/tests/opcode/no_space" $test_cnt_tmp

# Save information about the opcode tests
opcode_tests="${BOLD}${LIGHT_GRAY}Opcode:${DEFAULT}\n\t${GREEN}TESTS PASSED = $tests_passed_tmp/$test_cnt_tmp\n\t${RED}TESTS FAILED = $(($test_cnt_tmp - $tests_passed_tmp))/$test_cnt_tmp\n\n${DEFAULT}"
tests_passed_tmp=0
test_cnt_tmp=0

# TESTS 29 - 87 (operands)
test_script_args 0 23 "Too many operands ~ version 1" $test_cnt "" "/tests/operands/too_many_1" $test_cnt_tmp
test_script_args 0 23 "Too many operands ~ version 2" $test_cnt "" "/tests/operands/too_many_2" $test_cnt_tmp 
test_script_args 0 23 "Too many operands ~ version 3" $test_cnt "" "/tests/operands/extra_arg_err" $test_cnt_tmp
test_script_args 0 23 "Too few operands ~ version 1" $test_cnt "" "/tests/operands/too_few_1" $test_cnt_tmp
test_script_args 0 23 "Too few operands ~ version 2" $test_cnt "" "/tests/operands/too_few_2" $test_cnt_tmp
test_script_args 0 23 "Invalid lowercased operand" $test_cnt "" "/tests/operands/lowercased" $test_cnt_tmp
test_script_args 0 23 "Invalid uppercased operand" $test_cnt "" "/tests/operands/uppercased" $test_cnt_tmp
test_script_args 0 23 "Invalid mix of lowercased and uppercased operands ~ version 1" $test_cnt "" "/tests/operands/mixed_1" $test_cnt_tmp
test_script_args 0 23 "Invalid mix of lowercased and uppercased operands ~ version 1" $test_cnt "" "/tests/operands/mixed_2" $test_cnt_tmp
test_script_args 0 23 "Incorrect 'var' operand syntax" $test_cnt "" "/tests/operands/var_invalid" $test_cnt_tmp
test_script_args 0 0  "Correct 'var' operand syntax" $test_cnt "" "/tests/operands/var_valid" $test_cnt_tmp
test_script_args 0 23 "Incorrect 'type' operand syntax" $test_cnt "" "/tests/operands/type_invalid" $test_cnt_tmp
test_script_args 0 0  "Correct 'type' operand syntax" $test_cnt "" "/tests/operands/type_valid" $test_cnt_tmp
test_script_args 0 23 "Incorrect 'label' operand syntax ~ version 1" $test_cnt "" "/tests/operands/label_invalid_1" $test_cnt_tmp
test_script_args 0 23 "Incorrect 'label' operand syntax ~ version 2" $test_cnt "" "/tests/operands/label_invalid_2" $test_cnt_tmp
test_script_args 0 0 "Correct 'symb' operand syntax ~ version 1" $test_cnt "" "/tests/operands/allowed_string_test_1" $test_cnt_tmp
test_script_args 0 0 "Correct 'symb' operand syntax ~ version 2" $test_cnt "" "/tests/operands/allowed_string_test_2" $test_cnt_tmp
test_script_args 0 23 "Incorrect 'symb' operand syntax ~ version 1" $test_cnt "" "/tests/operands/not_allowed_string_test_1" $test_cnt_tmp
test_script_args 0 23 "Incorrect 'symb' operand syntax ~ version 2" $test_cnt "" "/tests/operands/not_allowed_string_test_2" $test_cnt_tmp
test_script_args 0 23 "Incorrect 'symb' operand syntax ~ version 3" $test_cnt "" "/tests/operands/not_allowed_string_test_3" $test_cnt_tmp
test_script_args 0 23 "Incorrect 'symb' operand syntax ~ version 4" $test_cnt "" "/tests/operands/not_allowed_string_test_4" $test_cnt_tmp
test_script_args 0 0  "Correct 'label' operand syntax" $test_cnt "" "/tests/operands/label_valid" $test_cnt_tmp
test_script_args 0 23 "Incorrect 'bool@0' value" $test_cnt "" "/tests/operands/0" $test_cnt_tmp
test_script_args 0 0 "Hexadecimal integer with capitalized X" $test_cnt "" "/tests/operands/hex_correct_2" $test_cnt_tmp
test_script_args 0 0 "Hexadecimal integer with not capitalized x" $test_cnt "" "/tests/operands/hex_correct_3" $test_cnt_tmp
test_script_args 0 0 "Correct hexadecimal integer" $test_cnt "" "/tests/operands/hex_correct" $test_cnt_tmp
test_script_args 0 23 "Incorrect hexadecimal integer" $test_cnt "" "/tests/operands/hex_incorrect" $test_cnt_tmp
test_script_args 0 0 "Octal integer with capitalized O" $test_cnt "" "/tests/operands/octa_correct_2" $test_cnt_tmp
test_script_args 0 0 "Octal integer with not capitalized o" $test_cnt "" "/tests/operands/octa_correct_3" $test_cnt_tmp
test_script_args 0 0 "Correct octal integer" $test_cnt "" "/tests/operands/octa_correct" $test_cnt_tmp
test_script_args 0 23 "Incorrect octal integer" $test_cnt "" "/tests/operands/octa_incorrect" $test_cnt_tmp
test_script_args 0 0 "Negative integer" $test_cnt "" "/tests/operands/negative_int" $test_cnt_tmp
test_script_args 0 0 "Positive integer" $test_cnt "" "/tests/operands/positive_int" $test_cnt_tmp
test_script_args 0 23 "Missing '@'" $test_cnt "" "/tests/operands/missing_@" $test_cnt_tmp
test_script_args 0 23 "Double '@'" $test_cnt "" "/tests/operands/double_@" $test_cnt_tmp
test_script_args 0 23 "Push error" $test_cnt "" "/tests/operands/push_error" $test_cnt_tmp
test_script_args 0 23 "Pop error" $test_cnt "" "/tests/operands/pop_error" $test_cnt_tmp
test_script_args 0 23 "Random operand test - @." $test_cnt "" "/tests/operands/random/@." $test_cnt_tmp
test_script_args 0 23 "Random operand test - 1operand" $test_cnt "" "/tests/operands/random/1operand" $test_cnt_tmp
test_script_args 0 23 "Random operand test - 1param" $test_cnt "" "/tests/operands/random/1param" $test_cnt_tmp
test_script_args 0 23 "Random operand test - 3operands" $test_cnt "" "/tests/operands/random/3operands" $test_cnt_tmp
test_script_args 0 23 "Random operand test - cases" $test_cnt "" "/tests/operands/random/cases" $test_cnt_tmp
test_script_args 0 23 "Random operand test - empty" $test_cnt "" "/tests/operands/random/empty" $test_cnt_tmp
test_script_args 0 23 "Random operand test - label" $test_cnt "" "/tests/operands/random/label" $test_cnt_tmp
test_script_args 0 23 "Random operand test - LF@" $test_cnt "" "/tests/operands/random/LF@" $test_cnt_tmp
test_script_args 0 23 "Random operand test - no@" $test_cnt "" "/tests/operands/random/no@" $test_cnt_tmp
test_script_args 0 23 "Random operand test - no@nil" $test_cnt "" "/tests/operands/random/no@nil" $test_cnt_tmp
test_script_args 0 23 "Random operand test - operands" $test_cnt "" "/tests/operands/random/operands" $test_cnt_tmp
test_script_args 0 23 "Random operand test - simple00" $test_cnt "" "/tests/operands/random/simple00" $test_cnt_tmp
test_script_args 0 23 "Random operand test - simple10" $test_cnt "" "/tests/operands/random/simple10" $test_cnt_tmp
test_script_args 0 23 "Random operand test - simple11" $test_cnt "" "/tests/operands/random/simple11" $test_cnt_tmp
test_script_args 0 23 "Random operand test - simple12" $test_cnt "" "/tests/operands/random/simple12" $test_cnt_tmp
test_script_args 0 23 "Random operand test - simple13" $test_cnt "" "/tests/operands/random/simple13" $test_cnt_tmp
test_script_args 0 23 "Random operand test - simple15" $test_cnt "" "/tests/operands/random/simple15" $test_cnt_tmp
test_script_args 0 23 "Random operand test - slash" $test_cnt "" "/tests/operands/random/slash" $test_cnt_tmp
test_script_args 0 23 "Random operand test - specialChar8" $test_cnt "" "/tests/operands/random/specialChar8" $test_cnt_tmp
test_script_args 0 23 "Random operand test - specialChar9" $test_cnt "" "/tests/operands/random/specialChar9" $test_cnt_tmp
test_script_args 0 23 "Random operand test - symbSymb" $test_cnt "" "/tests/operands/random/symbSymb" $test_cnt_tmp
test_script_args 0 23 "Random operand test - upper" $test_cnt "" "/tests/operands/random/upper" $test_cnt_tmp

# Save information about the operand tests
opcode_arg_tests="${BOLD}${LIGHT_GRAY}Operands:${DEFAULT}\n\t${GREEN}TESTS PASSED = $tests_passed_tmp/$test_cnt_tmp\n\t${RED}TESTS FAILED = $(($test_cnt_tmp - $tests_passed_tmp))/$test_cnt_tmp\n\n${DEFAULT}"
tests_passed_tmp=0
test_cnt_tmp=0

# TESTS 88 - 171 (XML generation)
if [ "$rc_tests_only" = "N" ]
then  
    test_script_output 0 "Testing the XML code generation - read" $test_cnt "/tests/XML_gen/read_test.src" "/tests/XML_gen/read_test.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - simple tag" $test_cnt "/tests/XML_gen/simple_tag.src" "/tests/XML_gen/simple_tag.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - write" $test_cnt "/tests/XML_gen/write_test.src" "/tests/XML_gen/write_test.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - comments" $test_cnt "/tests/XML_gen/comments_test.src" "/tests/XML_gen/comments_test.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - decimal integer" $test_cnt "/tests/XML_gen/dec_int_test.src" "/tests/XML_gen/dec_int_test.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - hexadecimal integer" $test_cnt "/tests/XML_gen/hex_int_test.src" "/tests/XML_gen/hex_int_test.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - empty" $test_cnt "/tests/XML_gen/empty_test.src" "/tests/XML_gen/empty_test.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - label type" $test_cnt "/tests/XML_gen/label_type_test.src" "/tests/XML_gen/label_type_test.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - not" $test_cnt "/tests/XML_gen/not_test.src" "/tests/XML_gen/not_test.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - octal integer" $test_cnt "/tests/XML_gen/oct_int_test.src" "/tests/XML_gen/oct_int_test.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - opcode case insensitive" $test_cnt "/tests/XML_gen/op_code_case_insensitive.src" "/tests/XML_gen/op_code_case_insensitive.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - random program" $test_cnt "/tests/XML_gen/random_prog_1.src" "/tests/XML_gen/random_prog_1.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - symbol" $test_cnt "/tests/XML_gen/symbol_test.src" "/tests/XML_gen/symbol_test.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - false test" $test_cnt "/tests/XML_gen/false.src" "/tests/XML_gen/false.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - true test" $test_cnt "/tests/XML_gen/true.src" "/tests/XML_gen/true.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - call test" $test_cnt "/tests/XML_gen/ok.src" "/tests/XML_gen/ok.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - createframe test" $test_cnt "/tests/XML_gen/ok_createFrame.src" "/tests/XML_gen/ok_createFrame.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - lf test" $test_cnt "/tests/XML_gen/LF.src" "/tests/XML_gen/LF.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - more spaces test" $test_cnt "/tests/XML_gen/moreSpaces.src" "/tests/XML_gen/moreSpaces.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - number test" $test_cnt "/tests/XML_gen/number.src" "/tests/XML_gen/number.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - number test 2" $test_cnt "/tests/XML_gen/number3.src" "/tests/XML_gen/number3.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - defvar test" $test_cnt "/tests/XML_gen/ok_defvar.src" "/tests/XML_gen/ok_defvar.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - only header test" $test_cnt "/tests/XML_gen/only_header_test.src" "/tests/XML_gen/only_header_test.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - specialchars test" $test_cnt "/tests/XML_gen/specialChars.src" "/tests/XML_gen/specialChars.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - specialchars test 2" $test_cnt "/tests/XML_gen/specialChars2.src" "/tests/XML_gen/specialChars2.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - specialchars test 3" $test_cnt "/tests/XML_gen/specialChars4.src" "/tests/XML_gen/specialChars4.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - specialchars test 4" $test_cnt "/tests/XML_gen/specialCharsOk1.src" "/tests/XML_gen/specialCharsOk1.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - specialchars test 5" $test_cnt "/tests/XML_gen/specialCharsOk2.src" "/tests/XML_gen/specialCharsOk2.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - specialchars test 6" $test_cnt "/tests/XML_gen/specialCharsOk3.src" "/tests/XML_gen/specialCharsOk3.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - specialchars test 7" $test_cnt "/tests/XML_gen/specialCharsOk4.src" "/tests/XML_gen/specialCharsOk4.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - specialchars test 8" $test_cnt "/tests/XML_gen/specialCharsOk5.src" "/tests/XML_gen/specialCharsOk5.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - specialchars test 9" $test_cnt "/tests/XML_gen/specialCharsOk6.src" "/tests/XML_gen/specialCharsOk6.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - specialchars test 10" $test_cnt "/tests/XML_gen/specialCharsOk7.src" "/tests/XML_gen/specialCharsOk7.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - specialchars test 11" $test_cnt "/tests/XML_gen/specialCharsOk8.src" "/tests/XML_gen/specialCharsOk8.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - specialchars test 12" $test_cnt "/tests/XML_gen/specialChar1.src" "/tests/XML_gen/specialChar1.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - specialchars test 13" $test_cnt "/tests/XML_gen/specialChar2.src" "/tests/XML_gen/specialChar2.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - specialchars test 14" $test_cnt "/tests/XML_gen/specialChar3.src" "/tests/XML_gen/specialChar3.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - specialchars test 15" $test_cnt "/tests/XML_gen/specialChar4.src" "/tests/XML_gen/specialChar4.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - specialchars test 16" $test_cnt "/tests/XML_gen/specialChar5.src" "/tests/XML_gen/specialChar5.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - specialchars test 17" $test_cnt "/tests/XML_gen/specialChar6.src" "/tests/XML_gen/specialChar6.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - specialchars test 18" $test_cnt "/tests/XML_gen/specialChar7.src" "/tests/XML_gen/specialChar7.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - specialchars test 19" $test_cnt "/tests/XML_gen/specialCharDouble.src" "/tests/XML_gen/specialCharDouble.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - tf test" $test_cnt "/tests/XML_gen/TF.src" "/tests/XML_gen/TF.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - blank line test" $test_cnt "/tests/XML_gen/blankLine.src" "/tests/XML_gen/blankLine.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - cases test" $test_cnt "/tests/XML_gen/cases.src" "/tests/XML_gen/cases.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - cases test 2" $test_cnt "/tests/XML_gen/cases2.src" "/tests/XML_gen/cases2.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - comments test" $test_cnt "/tests/XML_gen/comment1.src" "/tests/XML_gen/comment1.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - comments test 2" $test_cnt "/tests/XML_gen/comment2.src" "/tests/XML_gen/comment2.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - comments test 3" $test_cnt "/tests/XML_gen/comment2.src" "/tests/XML_gen/comment2.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - comments test 4" $test_cnt "/tests/XML_gen/comment3.src" "/tests/XML_gen/comment3.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - comments test 5" $test_cnt "/tests/XML_gen/comment4.src" "/tests/XML_gen/comment4.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - comment test 6" $test_cnt "/tests/XML_gen/comment.src" "/tests/XML_gen/comment.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - spaces test" $test_cnt "/tests/XML_gen/spaces.src" "/tests/XML_gen/spaces.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - spaces test 2" $test_cnt "/tests/XML_gen/spaces2.src" "/tests/XML_gen/spaces2.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - uppercase test" $test_cnt "/tests/XML_gen/upperCase.src" "/tests/XML_gen/upperCase.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - long int test" $test_cnt "/tests/XML_gen/longInt.src" "/tests/XML_gen/longInt.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - int test" $test_cnt "/tests/XML_gen/int_ok.src" "/tests/XML_gen/int_ok.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - int test 2" $test_cnt "/tests/XML_gen/int_ok1.src" "/tests/XML_gen/int_ok1.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - int test 3" $test_cnt "/tests/XML_gen/int_ok2.src" "/tests/XML_gen/int_ok2.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - int test 4" $test_cnt "/tests/XML_gen/int_ok3.src" "/tests/XML_gen/int_ok3.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - label test" $test_cnt "/tests/XML_gen/ok_label.src" "/tests/XML_gen/ok_label.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - simple test" $test_cnt "/tests/XML_gen/simple14.src" "/tests/XML_gen/simple14.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - upper label test" $test_cnt "/tests/XML_gen/upper_label.src" "/tests/XML_gen/upper_label.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - move test" $test_cnt "/tests/XML_gen/ok_move.src" "/tests/XML_gen/ok_move.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - var test" $test_cnt "/tests/XML_gen/varVar.src" "/tests/XML_gen/varVar.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - var test 2" $test_cnt "/tests/XML_gen/var.src" "/tests/XML_gen/var.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - nil test" $test_cnt "/tests/XML_gen/ok_nil.src" "/tests/XML_gen/ok_nil.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - opcode test" $test_cnt "/tests/XML_gen/cases_opcode.src" "/tests/XML_gen/cases_opcode.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - opcode test 2" $test_cnt "/tests/XML_gen/comment3_opcode.src" "/tests/XML_gen/comment3_opcode.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - opcode test 3" $test_cnt "/tests/XML_gen/ok_opcode.src" "/tests/XML_gen/ok_opcode.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - small case test" $test_cnt "/tests/XML_gen/smallcase.src" "/tests/XML_gen/smallcase.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - popframe test" $test_cnt "/tests/XML_gen/ok_popframe.src" "/tests/XML_gen/ok_popframe.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - pushframe test" $test_cnt "/tests/XML_gen/ok_pushframe.src" "/tests/XML_gen/ok_pushframe.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - pushs test" $test_cnt "/tests/XML_gen/bool_pushs.src" "/tests/XML_gen/bool_pushs.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - pushs test 2" $test_cnt "/tests/XML_gen/int_pushs.src" "/tests/XML_gen/int_pushs.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - pushs test 3" $test_cnt "/tests/XML_gen/nil_pushs.src" "/tests/XML_gen/nil_pushs.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - pushs test 4" $test_cnt "/tests/XML_gen/var_pushs.src" "/tests/XML_gen/var_pushs.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - string test" $test_cnt "/tests/XML_gen/string.src" "/tests/XML_gen/string.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - string test 2" $test_cnt "/tests/XML_gen/comment_string.src" "/tests/XML_gen/comment_string.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - string test 3" $test_cnt "/tests/XML_gen/empty_string.src" "/tests/XML_gen/empty_string.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - return test" $test_cnt "/tests/XML_gen/ok_return.src" "/tests/XML_gen/ok_return.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - escape seq test" $test_cnt "/tests/XML_gen/escape.src" "/tests/XML_gen/escape.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - escape seq test 2" $test_cnt "/tests/XML_gen/escape2.src" "/tests/XML_gen/escape2.out" $test_cnt_tmp
    test_script_output 0 "Testing the XML code generation - numbers test" $test_cnt "/tests/XML_gen/numbers.src" "/tests/XML_gen/numbers.out" $test_cnt_tmp

    # Save information about the XML generation tests
    XML_generation_tests="${BOLD}${LIGHT_GRAY}XML generation:${DEFAULT}\n\t${GREEN}TESTS PASSED = $tests_passed_tmp/$test_cnt_tmp\n\t${RED}TESTS FAILED = $(($test_cnt_tmp - $tests_passed_tmp))/$test_cnt_tmp\n\n${DEFAULT}"
    tests_passed_tmp=0
    test_cnt_tmp=0

    # Check if the user wants to run the generated tests
    if $ask_user
    then
        echo -e "${RED}IMPORTANT: Do you want me to run the generated tests??\n\n${GREEN}It may take some time to finish... [Y/n]"
        read -s generated_tests
        printf "\n"
    fi

    if [ "$generated_tests" = "Y" ] || [ "$generated_tests" = "y" ]  
    then
        # Run the generated tests

        # TESTS 172 - 158 (XML generation)

        for file in "./tests/GENERATED/add"/*.src; do
            test_name=$(echo "$file" | rev | cut -d '.' -f2 | cut -d '/' -f1 | rev)
            test_script_output 0 "Testing random XML generated code - add $test_name test" $test_cnt "/tests/GENERATED/add/$test_name.src" "/tests/GENERATED/add/$test_name.out" $test_cnt_tmp
        done

        # Remove all the .log files
        rm $(pwd)/tests/GENERATED/add/*.log > /dev/null 2>&1

        for file in "./tests/GENERATED/and"/*.src; do
            test_name=$(echo "$file" | rev | cut -d '.' -f2 | cut -d '/' -f1 | rev)
            test_script_output 0 "Testing random XML generated code - and $test_name test" $test_cnt "/tests/GENERATED/and/$test_name.src" "/tests/GENERATED/and/$test_name.out" $test_cnt_tmp
        done

        # Remove all the .log files
        rm $(pwd)/tests/GENERATED/and/*.log > /dev/null 2>&1

        for file in "./tests/GENERATED/break"/*.src; do
            test_name=$(echo "$file" | rev | cut -d '.' -f2 | cut -d '/' -f1 | rev)
            test_script_output 0 "Testing random XML generated code - break $test_name test" $test_cnt "/tests/GENERATED/break/$test_name.src" "/tests/GENERATED/break/$test_name.out" $test_cnt_tmp
        done

        # Remove all the .log files
        rm $(pwd)/tests/GENERATED/break/*.log > /dev/null 2>&1

        for file in "./tests/GENERATED/concat"/*.src; do
            test_name=$(echo "$file" | rev | cut -d '.' -f2 | cut -d '/' -f1 | rev)
            test_script_output 0 "Testing random XML generated code - concat $test_name test" $test_cnt "/tests/GENERATED/concat/$test_name.src" "/tests/GENERATED/concat/$test_name.out" $test_cnt_tmp
        done

        # Remove all the .log files
        rm $(pwd)/tests/GENERATED/concat/*.log > /dev/null 2>&1

        for file in "./tests/GENERATED/dprint"/*.src; do
            test_name=$(echo "$file" | rev | cut -d '.' -f2 | cut -d '/' -f1 | rev)
            test_script_output 0 "Testing random XML generated code - dprint $test_name test" $test_cnt "/tests/GENERATED/dprint/$test_name.src" "/tests/GENERATED/dprint/$test_name.out" $test_cnt_tmp
        done

        # Remove all the .log files
        rm $(pwd)/tests/GENERATED/dprint/*.log > /dev/null 2>&1

        for file in "./tests/GENERATED/eq"/*.src; do
            test_name=$(echo "$file" | rev | cut -d '.' -f2 | cut -d '/' -f1 | rev)
            test_script_output 0 "Testing random XML generated code - eq $test_name test" $test_cnt "/tests/GENERATED/eq/$test_name.src" "/tests/GENERATED/eq/$test_name.out" $test_cnt_tmp
        done

        # Remove all the .log files
        rm $(pwd)/tests/GENERATED/eq/*.log > /dev/null 2>&1

        for file in "./tests/GENERATED/exit"/*.src; do
            test_name=$(echo "$file" | rev | cut -d '.' -f2 | cut -d '/' -f1 | rev)
            test_script_output 0 "Testing random XML generated code - exit $test_name test" $test_cnt "/tests/GENERATED/exit/$test_name.src" "/tests/GENERATED/exit/$test_name.out" $test_cnt_tmp
        done

        # Remove all the .log files
        rm $(pwd)/tests/GENERATED/exit/*.log > /dev/null 2>&1

        for file in "./tests/GENERATED/getchar"/*.src; do
            test_name=$(echo "$file" | rev | cut -d '.' -f2 | cut -d '/' -f1 | rev)
            test_script_output 0 "Testing random XML generated code - getchar $test_name test" $test_cnt "/tests/GENERATED/getchar/$test_name.src" "/tests/GENERATED/getchar/$test_name.out" $test_cnt_tmp
        done

        # Remove all the .log files
        rm $(pwd)/tests/GENERATED/getchar/*.log > /dev/null 2>&1

        for file in "./tests/GENERATED/gt"/*.src; do
            test_name=$(echo "$file" | rev | cut -d '.' -f2 | cut -d '/' -f1 | rev)
            test_script_output 0 "Testing random XML generated code - gt $test_name test" $test_cnt "/tests/GENERATED/gt/$test_name.src" "/tests/GENERATED/gt/$test_name.out" $test_cnt_tmp
        done

        # Remove all the .log files
        rm $(pwd)/tests/GENERATED/gt/*.log > /dev/null 2>&1

        for file in "./tests/GENERATED/idiv"/*.src; do
            test_name=$(echo "$file" | rev | cut -d '.' -f2 | cut -d '/' -f1 | rev)
            test_script_output 0 "Testing random XML generated code - idiv $test_name test" $test_cnt "/tests/GENERATED/idiv/$test_name.src" "/tests/GENERATED/idiv/$test_name.out" $test_cnt_tmp
        done

        # Remove all the .log files
        rm $(pwd)/tests/GENERATED/idiv/*.log > /dev/null 2>&1

        for file in "./tests/GENERATED/int2char"/*.src; do
            test_name=$(echo "$file" | rev | cut -d '.' -f2 | cut -d '/' -f1 | rev)
            test_script_output 0 "Testing random XML generated code - int2char $test_name test" $test_cnt "/tests/GENERATED/int2char/$test_name.src" "/tests/GENERATED/int2char/$test_name.out" $test_cnt_tmp
        done

        # Remove all the .log files
        rm $(pwd)/tests/GENERATED/int2char/*.log > /dev/null 2>&1

        for file in "./tests/GENERATED/jump"/*.src; do
            test_name=$(echo "$file" | rev | cut -d '.' -f2 | cut -d '/' -f1 | rev)
            test_script_output 0 "Testing random XML generated code - jump $test_name test" $test_cnt "/tests/GENERATED/jump/$test_name.src" "/tests/GENERATED/jump/$test_name.out" $test_cnt_tmp
        done

        # Remove all the .log files
        rm $(pwd)/tests/GENERATED/jump/*.log > /dev/null 2>&1

        for file in "./tests/GENERATED/jumpifeq"/*.src; do
            test_name=$(echo "$file" | rev | cut -d '.' -f2 | cut -d '/' -f1 | rev)
            test_script_output 0 "Testing random XML generated code - jumpifeq $test_name test" $test_cnt "/tests/GENERATED/jumpifeq/$test_name.src" "/tests/GENERATED/jumpifeq/$test_name.out" $test_cnt_tmp
        done

        # Remove all the .log files
        rm $(pwd)/tests/GENERATED/jumpifeq/*.log > /dev/null 2>&1

        for file in "./tests/GENERATED/jumpifneq"/*.src; do
            test_name=$(echo "$file" | rev | cut -d '.' -f2 | cut -d '/' -f1 | rev)
            test_script_output 0 "Testing random XML generated code - jumpifneq $test_name test" $test_cnt "/tests/GENERATED/jumpifneq/$test_name.src" "/tests/GENERATED/jumpifneq/$test_name.out" $test_cnt_tmp
        done

        # Remove all the .log files
        rm $(pwd)/tests/GENERATED/jumpifneq/*.log > /dev/null 2>&1

        for file in "./tests/GENERATED/lt"/*.src; do
            test_name=$(echo "$file" | rev | cut -d '.' -f2 | cut -d '/' -f1 | rev)
            test_script_output 0 "Testing random XML generated code - lt $test_name test" $test_cnt "/tests/GENERATED/lt/$test_name.src" "/tests/GENERATED/lt/$test_name.out" $test_cnt_tmp
        done

        # Remove all the .log files
        rm $(pwd)/tests/GENERATED/lt/*.log > /dev/null 2>&1

        for file in "./tests/GENERATED/mul"/*.src; do
            test_name=$(echo "$file" | rev | cut -d '.' -f2 | cut -d '/' -f1 | rev)
            test_script_output 0 "Testing random XML generated code - mul $test_name test" $test_cnt "/tests/GENERATED/mul/$test_name.src" "/tests/GENERATED/mul/$test_name.out" $test_cnt_tmp
        done

        # Remove all the .log files
        rm $(pwd)/tests/GENERATED/mul/*.log > /dev/null 2>&1

        for file in "./tests/GENERATED/not"/*.src; do
            test_name=$(echo "$file" | rev | cut -d '.' -f2 | cut -d '/' -f1 | rev)
            test_script_output 0 "Testing random XML generated code - not $test_name test" $test_cnt "/tests/GENERATED/not/$test_name.src" "/tests/GENERATED/not/$test_name.out" $test_cnt_tmp
        done

        # Remove all the .log files
        rm $(pwd)/tests/GENERATED/not/*.log > /dev/null 2>&1

        for file in "./tests/GENERATED/or"/*.src; do
            test_name=$(echo "$file" | rev | cut -d '.' -f2 | cut -d '/' -f1 | rev)
            test_script_output 0 "Testing random XML generated code - or $test_name test" $test_cnt "/tests/GENERATED/or/$test_name.src" "/tests/GENERATED/or/$test_name.out" $test_cnt_tmp
        done

        # Remove all the .log files
        rm $(pwd)/tests/GENERATED/or/*.log > /dev/null 2>&1

        for file in "./tests/GENERATED/read"/*.src; do
            test_name=$(echo "$file" | rev | cut -d '.' -f2 | cut -d '/' -f1 | rev)
            test_script_output 0 "Testing random XML generated code - read $test_name test" $test_cnt "/tests/GENERATED/read/$test_name.src" "/tests/GENERATED/read/$test_name.out" $test_cnt_tmp
        done

        # Remove all the .log files
        rm $(pwd)/tests/GENERATED/read/*.log > /dev/null 2>&1

        for file in "./tests/GENERATED/setchar"/*.src; do
            test_name=$(echo "$file" | rev | cut -d '.' -f2 | cut -d '/' -f1 | rev)
            test_script_output 0 "Testing random XML generated code - setchar $test_name test" $test_cnt "/tests/GENERATED/setchar/$test_name.src" "/tests/GENERATED/setchar/$test_name.out" $test_cnt_tmp
        done

        # Remove all the .log files
        rm $(pwd)/tests/GENERATED/setchar/*.log > /dev/null 2>&1

        for file in "./tests/GENERATED/stri2int"/*.src; do
            test_name=$(echo "$file" | rev | cut -d '.' -f2 | cut -d '/' -f1 | rev)
            test_script_output 0 "Testing random XML generated code - stri2int $test_name test" $test_cnt "/tests/GENERATED/stri2int/$test_name.src" "/tests/GENERATED/stri2int/$test_name.out" $test_cnt_tmp
        done

        # Remove all the .log files
        rm $(pwd)/tests/GENERATED/stri2int/*.log > /dev/null 2>&1

        for file in "./tests/GENERATED/strlen"/*.src; do
            test_name=$(echo "$file" | rev | cut -d '.' -f2 | cut -d '/' -f1 | rev)
            test_script_output 0 "Testing random XML generated code - strlen $test_name test" $test_cnt "/tests/GENERATED/strlen/$test_name.src" "/tests/GENERATED/strlen/$test_name.out" $test_cnt_tmp
        done

        # Remove all the .log files
        rm $(pwd)/tests/GENERATED/strlen/*.log > /dev/null 2>&1

        for file in "./tests/GENERATED/sub"/*.src; do
            test_name=$(echo "$file" | rev | cut -d '.' -f2 | cut -d '/' -f1 | rev)
            test_script_output 0 "Testing random XML generated code - sub $test_name test" $test_cnt "/tests/GENERATED/sub/$test_name.src" "/tests/GENERATED/sub/$test_name.out" $test_cnt_tmp
        done

        # Remove all the .log files
        rm $(pwd)/tests/GENERATED/sub/*.log > /dev/null 2>&1

        for file in "./tests/GENERATED/type"/*.src; do
            test_name=$(echo "$file" | rev | cut -d '.' -f2 | cut -d '/' -f1 | rev)
            test_script_output 0 "Testing random XML generated code - type $test_name test" $test_cnt "/tests/GENERATED/type/$test_name.src" "/tests/GENERATED/type/$test_name.out" $test_cnt_tmp
        done

        # Remove all the .log files
        rm $(pwd)/tests/GENERATED/type/*.log > /dev/null 2>&1

        for file in "./tests/GENERATED/write"/*.src; do
            test_name=$(echo "$file" | rev | cut -d '.' -f2 | cut -d '/' -f1 | rev)
            test_script_output 0 "Testing random XML generated code - write $test_name test" $test_cnt "/tests/GENERATED/write/$test_name.src" "/tests/GENERATED/write/$test_name.out" $test_cnt_tmp
        done

        # Remove all the .log files
        rm $(pwd)/tests/GENERATED/write/*.log > /dev/null 2>&1

        # Save information about the generated tests
        random_generation_tests="${BOLD}${LIGHT_GRAY}Random XML generation:${DEFAULT}\n\t${GREEN}TESTS PASSED = $tests_passed_tmp/$test_cnt_tmp\n\t${RED}TESTS FAILED = $(($test_cnt_tmp - $tests_passed_tmp))/$test_cnt_tmp\n\n${DEFAULT}"
    fi
fi

# Print the specific tests summary
echo ""
printf "${YELLOW}/////////////////////////////////////\n"
printf "${YELLOW}//             SUMMARY             //\n"
printf "${YELLOW}/////////////////////////////////////\n\n"

printf "$program_args_tests"
printf "$file_header_tests"
printf "$tests"
printf "$opcode_tests"
printf "$opcode_arg_tests"

if [ "$rc_tests_only" = "N" ] 
then
    printf "$XML_generation_tests"

    if [ "$generated_tests" = "Y" ] || [ "$generated_tests" = "y" ]
    then
        printf "$random_generation_tests"
    fi

    # Delete all the temporary files
    rm "./diffs.xml" > /dev/null 2>&1
    rm "./tmp_file.out" > /dev/null 2>&1
    rm $(pwd)/tests/XML_gen/*.log > /dev/null 2>&1
fi

# Print the total tests summary
printf "${BOLD}${PURPLE}Total:\n\tTESTS PASSED = $tests_passed/$test_cnt\n\tTESTS FAILED = $(($test_cnt - $tests_passed))/$test_cnt\n"

if [ $tests_passed -eq $test_cnt ]
then
    xdg-open --version > /dev/null 2>&1
    if [ $? -eq 0 ]
    then
        xdg-open ./tests/__/klidecek.jpg > /dev/null 2>&1
    fi
fi

# Author ~ Marek Čupr (xcuprm01)
