How to run the tests: 
    1. Extract the 'IPP2024_tests_marocc.zip'
    2. Move your 'parse.py' file into the 'IPP2024_tests_marocc' directory
    3. cd IPP2024_tests_marocc
    4. chmod +x parser_tests.sh
    5. ./parser_tests.sh
    
Alternatives:
    ./parser_tests.sh -y   ...   run all the tests without asking for the user input
    ./parser_tests.sh -Y   ...   run all the tests without asking for the user input
    
DISCLAIMER:
    The current script is using python3 instead of python3.10 to run the tests... I recommend changing 'python3' to 'python3.10' at lines 83 and 116 in the parser_tests.sh file for more accuracy
    

@author ~ Marek Čupr (xcuprm01)
